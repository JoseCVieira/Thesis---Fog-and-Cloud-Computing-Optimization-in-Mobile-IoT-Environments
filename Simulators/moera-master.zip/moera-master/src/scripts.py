import sys
import random
import numpy as np

import util
import simulation


# util.seperate_trajectory_hourly_darmstadt(20150207)

# distance_matrix_file = "../data/distance/darmstadt_ap_dist.dat"
# trajectory_matrix_file = "../data/trajectory/darmstadt/hourly/20150207_14.dat"

distance_matrix_file = "../data/distance/rome_metro_dist.dat"
trajectory_matrix_file = "../data/trajectory/rome/rome_taxi_2014021216_trajectory.dat"


# Optimal, MOERA, Greedy, Performance, Operation, Static, Future
simulation.main(distance_matrix_file, trajectory_matrix_file, workload_type=1, selectiveness=1, solution_type="1100001", param_beta=0.1, num_future_slots=2)
