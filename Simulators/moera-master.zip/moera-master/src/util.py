import random
import numpy as np

from sys import *
from os import listdir
from os.path import join
from geopy.distance import vincenty


def read_stations(station_file):
    
    stations = []
    stations_file_handler = open(station_file, 'r')
    lines = stations_file_handler.readlines()

    for line in lines:
        eles = line.rstrip().split('\t')
        stations.append((eles[1], eles[2]))
    
    return len(stations), stations
    
    
def find_nearest_station(taxi_location, stations):

    min_distance = 10000
    min_index = -1
    for index in range(len(stations)):
        distance = vincenty(stations[index], taxi_location)
        if distance < min_distance:
            min_distance = distance
            min_index = index

    return min_index


def find_nearest_k_station(taxi_location, stations, k):

    index_distance = dict()

    for index in range(len(stations)):
        index_distance[index] = vincenty(stations[index], taxi_location)

    sorted(index_distance.items(), key=lambda (index, distance): distance, reverse = True)

    return index_distance.keys()[0:k]


def find_neighbors(station_adjacent_matrix, station):
    neighbors = []
    for user in range(len(station_adjacent_matrix)):
        if station_adjacent_matrix[station][user] == 1:
            neighbors.append(user)
    return neighbors


def generate_selection_matrix_file(num_users, num_stations, selectiveness, temp_file_dir):

    selection_matrix = [[0 for station in range(num_stations)] for user in range(num_users)]

    random.seed(a=None)

    for user in range(num_users):
        num_selected = 0
        for station in range(num_stations):
            if random.uniform(0,1) <= selectiveness:
                selection_matrix[user][station] = 1
                num_selected += 1
        if num_selected == 0:
            selection_matrix[user][random.randint(0, num_stations-1)] = 1

    selection_matrix_file_handler = open("./{}/selection.dat".format(temp_file_dir), 'w')

    for user in range(num_users):
        for station in range(num_stations):
            selection_matrix_file_handler.write("{} ".format(selection_matrix[user][station]))
        selection_matrix_file_handler.write('\n')

    selection_matrix_file_handler.close()


def read_selection_matrix(selection_matrix_file):

    selection_matrix = []
    selection_matrix_file_handler = open(selection_matrix_file, 'r')
    lines = selection_matrix_file_handler.readlines()
    selection_matrix_file_handler.close()

    for line in lines:
        selection_per_user = map(int, line.split())
        selection_matrix.append(selection_per_user)

    return selection_matrix


def generate_distance_matrix_file(station_file, distance_matrix_file):

    num_stations, stations = read_stations(station_file)

    distance_matrix = [[0 for col in range(num_stations)] for row in range(num_stations)]
    for row in range(num_stations):
        for col in range(num_stations):
            distance_matrix[row][col] = vincenty(stations[row], stations[col]).kilometers

    distance_file_handler = open(distance_matrix_file, 'w')

    for row in range(num_stations):
        for col in range(num_stations):
            distance_file_handler.write(str(distance_matrix[row][col]) + ' ')
            distance_file_handler.write('\n')

    distance_file_handler.close()


def read_distance_matrix(distance_matrix_file):

    distance_matrix = []
    distance_matrix_file_handler = open(distance_matrix_file, 'r')
    lines = distance_matrix_file_handler.readlines()
    distance_matrix_file_handler.close()

    for line in lines:
        di = map(float, line.split())
        distance_matrix.append(di)

    return distance_matrix
    
    
def generate_trajectory_matrix_file(station_file, trajectory_path, trajectory_matrix_file):
    
    num_stations, stations = read_stations(station_file)
    
    taxi_files = [join(trajectory_path, f) for f in listdir(trajectory_path)]
    num_taxis = len(taxi_files)
    
    trajectory_matrix = []
    for file in taxi_files:
        file_handler = open(file, 'r')
        lines = file_handler.readlines()
        taxi_trajectory = []
        for line in lines:
            taxi_location = map(float, line.rstrip().split('\t')[3:5])
            taxi_station = find_nearest_station(taxi_location, stations)
            taxi_trajectory.append(taxi_station)
        trajectory_matrix.append(taxi_trajectory)
        file_handler.close()
    
    trajectory_matrix_file_handler = open(trajectory_matrix_file, 'w')
    for taxi_trajectory in trajectory_matrix:
        for station in taxi_trajectory:
            trajectory_matrix_file_handler.write(str(station) + ' ')
        trajectory_matrix_file_handler.write('\n')
    trajectory_matrix_file_handler.close()
    

def generate_random_trajectory_matrix_file(station_adjacent_matrix_file, trajectory_matrix_file, num_users, num_timeslots):
    
    station_adjacent_file_handler = open(station_adjacent_matrix_file,'r')
    lines = station_adjacent_file_handler.readlines()
    
    station_adjacent_matrix = []
    for line in lines:
        station_adjacent_matrix.append(map(int, line.split()))
    num_stations = len(station_adjacent_matrix)
    
    trajectory_matrix_file_handler = open(trajectory_matrix_file, 'w')
    
    trajectory_matrix = [[0 for time in range(num_timeslots)] for user in range(num_users)]
    for user in range(num_users):
        trajectory_matrix[user][0] = random.randint(0, num_stations)
        for time in range(1, num_timeslots):
            neighbors = find_neighbors(station_adjacent_matrix, trajectory_matrix[user][time-1])
            trajectory_matrix[user][time] = neighbors[random.randint(0, len(neighbors)-1)]
            
    for user in range(num_users):
        for time in range(num_timeslots):
            if time == num_timeslots - 1:
                trajectory_matrix_file_handler.write("{}".format(trajectory_matrix[user][time]))
            else:
                trajectory_matrix_file_handler.write("{} ".format(trajectory_matrix[user][time]))
        if user != num_users - 1:
            trajectory_matrix_file_handler.write("\n")
    
    trajectory_matrix_file_handler.close()


def read_trajectory_matrix(trajectory_matrix_file):

    trajectory_matrix = []
    trajectory_matrix_file_handler = open(trajectory_matrix_file, 'r')
    lines = trajectory_matrix_file_handler.readlines()
    trajectory_matrix_file_handler.close()

    for line in lines:
        loc_user = map(int, line.rstrip().split())
        trajectory_matrix.append(loc_user)

    return trajectory_matrix
    
    
def generate_operation_price_matrix_file(num_stations, num_timeslots, temp_file_dir):

    operation_price_matrix_file_handler = open("./{}/operation_price.dat".format(temp_file_dir), 'w')
    bases = [random.uniform(1, 5) for i in range(num_stations)]

    operation_price_matrix = []
    for station in range(num_stations):
        operation_price_matrix.append([abs(random.gauss(bases[station], 1)) for time in range(num_timeslots)])
        for val in operation_price_matrix[station]:
            operation_price_matrix_file_handler.write("{} ".format(val))
        if station != num_stations - 1:
            operation_price_matrix_file_handler.write("\n")

    operation_price_matrix_file_handler.close()
    return operation_price_matrix


def read_operation_price_matrix(operation_price_matrix_file):

    operation_price_matrix = []
    operation_price_matrix_file_handler = open(operation_price_matrix_file, 'r')
    lines = operation_price_matrix_file_handler.readlines()
    operation_price_matrix_file_handler.close()

    for line in lines:
        operation_price = map(float, line.split())
        operation_price_matrix.append(operation_price)

    return operation_price_matrix


def generate_bandwidth_price_matrix_file(num_stations, temp_file_dir):

    bandwidth_price_matrix_file_handler = open("./{}/bandwidth_price.dat".format(temp_file_dir), 'w')

    bandwidth_price_matrix = [0 for station in range(num_stations)]
    group = [station for station in range(num_stations)]
    random.shuffle(group)

    for station in range(num_stations):
        if station % 3 == 0:
            bandwidth_price_matrix[group[station]] = 0.5
        if station % 3 == 1:
            bandwidth_price_matrix[group[station]] = 1
        if station % 3 == 2:
            bandwidth_price_matrix[group[station]] = 2

    for station in range(num_stations):
        if station != num_stations - 1:
            bandwidth_price_matrix_file_handler.write("{}\n".format(bandwidth_price_matrix[station]))
        else:
            bandwidth_price_matrix_file_handler.write("{}".format(bandwidth_price_matrix[station]))

    bandwidth_price_matrix_file_handler.close()
    return bandwidth_price_matrix


def read_bandwidth_price_matrix(bandwidth_price_matrix_file):

    bandwidth_price_matrix = []
    bandwidth_price_matrix_file_handler = open(bandwidth_price_matrix_file, 'r')
    lines = bandwidth_price_matrix_file_handler.readlines()
    bandwidth_price_matrix_file_handler.close()

    for line in lines:
        bandwidth_price_matrix.append(line.rstrip())

    return map(float, bandwidth_price_matrix)


def generate_reconfiguration_price_file(num_stations, temp_file_dir):

    reconfiguration_price_file_handler = open("./{}/reconfiguration_price.dat".format(temp_file_dir), 'w')
    reconfiguration_price_matrix = [abs(random.normalvariate(5, 5)) for station in range(num_stations)]
    for station in range(num_stations):
        if station != num_stations - 1:
            reconfiguration_price_file_handler.write("{}\n".format(reconfiguration_price_matrix[station]))
        else:
            reconfiguration_price_file_handler.write("{}".format(reconfiguration_price_matrix[station]))

    reconfiguration_price_file_handler.close()
    return reconfiguration_price_matrix


def read_reconfiguration_price_matrix(reconfiguration_price_matrix_file):

    reconfiguration_price_matrix = []
    reconfiguration_price_matrix_file_handle = open(reconfiguration_price_matrix_file, 'r')
    lines = reconfiguration_price_matrix_file_handle.readlines()
    reconfiguration_price_matrix_file_handle.close()

    for line in lines:
        reconfiguration_price_matrix.append(line.rstrip())

    return map(float, reconfiguration_price_matrix)


def generate_workload_matrix_file(num_users, workload_type, temp_file_dir):

    workload_matrix = []
    if workload_type == 1:
        workload_matrix = np.random.power(1, num_users) * 10
    elif workload_type == 2:
        workload_matrix = [abs(random.normalvariate(10, 3)) for user in range(num_users)]
    else:
        workload_matrix = [random.uniform(5, 15) for j in range(num_users)]

    workload_matrix_file_handler = open("./{}/workload.dat".format(temp_file_dir), 'w')
    for user in range(num_users):
        if user != num_users - 1:
            workload_matrix_file_handler.write("{}\n".format(workload_matrix[user]))
        else:
            workload_matrix_file_handler.write("{}".format(workload_matrix[user]))

    workload_matrix_file_handler.close()
    return workload_matrix


def read_workload_matrix(workload_matrix_file):

    workload_matrix = []
    workload_matrix_file_handler = open(workload_matrix_file, 'r')
    lines = workload_matrix_file_handler.readlines()
    workload_matrix_file_handler.close()

    for line in lines:
        workload_matrix.append(line.rstrip())

    return map(float, workload_matrix)


def generate_capacity_matrix_file(num_stations, workload_matrix, trajectory_matrix, temp_file_dir):

    total_capacity = sum(workload_matrix) * 1.25


    capacity_matrix = [0 for station in range(num_stations)]

    appearance = [0 for station in range(num_stations)]
    for user_trajectory in trajectory_matrix:
        for station in range(num_stations):
            appearance[station] += user_trajectory.count(station)

    for station in range(num_stations):
        capacity_matrix[station] = total_capacity * appearance[station] / sum(appearance)

    capacity_matrix_file_handler = open("./{}/capacity.dat".format(temp_file_dir), 'w')
    for station in range(num_stations):
        if station != num_stations - 1:
            capacity_matrix_file_handler.write("{}\n".format(capacity_matrix[station]))
        else:
            capacity_matrix_file_handler.write("{}".format(capacity_matrix[station]))

    capacity_matrix_file_handler.close()
    return capacity_matrix


def read_capacity_matrix(capacity_matrix_file):

    capacity_matrix = []
    capacity_matrix_file_handler = open(capacity_matrix_file, 'r')
    lines = capacity_matrix_file_handler.readlines()
    capacity_matrix_file_handler.close()

    for line in lines:
        capacity_matrix.append(line.rstrip())

    return map(float, capacity_matrix)





def generate_optimal_input_file(optimal_input_file, num_stations, num_users, num_timeslots, operation_price_matrix, \
                                bandwidth_price_matrix, reconfiguration_price_matrix, distance_matrix, \
                                trajectory_matrix, selection_matrix, workload_matrix, capacity_matrix, param_alpha, param_beta):

    optimal_input_file_handler = open(optimal_input_file, 'w')
    optimal_input_file_handler.write("param t := {} ;\n".format(num_timeslots))
    optimal_input_file_handler.write("param i := {} ;\n".format(num_stations))
    optimal_input_file_handler.write("param j := {} ;\n".format(num_users))

    optimal_input_file_handler.write("param alpha := {} ;\n".format(param_alpha))
    optimal_input_file_handler.write("param beta := {} ;\n".format(param_beta))

    optimal_input_file_handler.write("param s := \n")
    for user in range(num_users):
        for station in range(num_stations):
            optimal_input_file_handler.write("{} {} {}\n".format(user+1, station+1, selection_matrix[user][station]))
    optimal_input_file_handler.write(";\n")

    optimal_input_file_handler.write("param a := \n")
    for station in range(num_stations):
        for time in range(num_timeslots):
            optimal_input_file_handler.write("{} {} {}\n".format(station+1, time+1, operation_price_matrix[station][time]))
    optimal_input_file_handler.write(";\n")

    optimal_input_file_handler.write("param c := \n")
    for station in range(num_stations):
        optimal_input_file_handler.write("{} {}\n".format(station+1, reconfiguration_price_matrix[station]))
    optimal_input_file_handler.write(";\n")

    optimal_input_file_handler.write("param b := \n")
    for station in range(num_stations):
        optimal_input_file_handler.write("{} {}\n".format(station+1, bandwidth_price_matrix[station]))
    optimal_input_file_handler.write(";\n")

    optimal_input_file_handler.write("param d := \n")
    for user in range(num_users):
        for station in range(num_stations):
            optimal_input_file_handler.write("[{},{},*] ".format(station+1, user+1))
            for time in range(num_timeslots):
                optimal_input_file_handler.write("{} {} ".format(time+1, distance_matrix[trajectory_matrix[user][time]][station]))
            optimal_input_file_handler.write("\n")
    optimal_input_file_handler.write(";\n")

    optimal_input_file_handler.write("param lbd := \n")
    for user in range(num_users):
        optimal_input_file_handler.write("{} {}\n".format(user+1, workload_matrix[user]))
    optimal_input_file_handler.write(";\n")

    optimal_input_file_handler.write("param cap := \n")
    for station in range(num_stations):
        optimal_input_file_handler.write("{} {}\n".format(station+1, capacity_matrix[station]))
    optimal_input_file_handler.write(";\n")

    optimal_input_file_handler.close()


def generate_moera_input_file(moera_input_file, current_time, num_stations, num_users, operation_price_matrix, \
                              bandwidth_price_matrix, reconfiguration_price_matrix, distance_matrix, trajectory_matrix, \
                              selection_matrix, workload_matrix, capacity_matrix, previous_solution_matrix, \
                              param_alpha, param_beta, param_eps1, param_eps2):
    moera_input_file_handler = open(moera_input_file, 'w')
    moera_input_file_handler.write("param i := {} ;\n".format(num_stations))
    moera_input_file_handler.write("param j := {} ;\n".format(num_users))

    moera_input_file_handler.write("param alpha := {} ;\n".format(param_alpha))
    moera_input_file_handler.write("param beta := {} ;\n".format(param_beta))

    moera_input_file_handler.write("param eps1 := {} ;\n".format(param_eps1))
    moera_input_file_handler.write("param eps2 := {} ;\n".format(param_eps2))

    moera_input_file_handler.write("param s := \n")
    for user in range(num_users):
        for station in range(num_stations):
            moera_input_file_handler.write("{} {} {}\n".format(user+1, station+1, selection_matrix[user][station]))
    moera_input_file_handler.write(";\n")

    moera_input_file_handler.write("param a :=\n")
    for station in range(num_stations):
        moera_input_file_handler.write("{} {}\n".format(station+1, operation_price_matrix[station][current_time]))
    moera_input_file_handler.write(";\n")

    moera_input_file_handler.write("param c := \n")
    for station in range(num_stations):
        if current_time == 0:
            moera_input_file_handler.write("{} {}\n".format(station+1, 0))
        else:
            moera_input_file_handler.write("{} {}\n".format(station+1, reconfiguration_price_matrix[station]))
    moera_input_file_handler.write(";\n")

    moera_input_file_handler.write("param b := \n")
    for station in range(num_stations):
        if current_time == 0:
            moera_input_file_handler.write("{} {}\n".format(station+1, 0))
        else:
            moera_input_file_handler.write("{} {}\n".format(station+1, bandwidth_price_matrix[station]))
    moera_input_file_handler.write(";\n")

    moera_input_file_handler.write("param lbd := \n")
    for user in range(num_users):
        moera_input_file_handler.write("{} {}\n".format(user+1, workload_matrix[user]))
    moera_input_file_handler.write(";\n")

    moera_input_file_handler.write("param cap := \n")
    for station in range(num_stations):
        moera_input_file_handler.write("{} {}\n".format(station+1, capacity_matrix[station]))
    moera_input_file_handler.write(";\n")

    moera_input_file_handler.write("param d := \n")
    for user in range(num_users):
        for station in range(num_stations):
            moera_input_file_handler.write("{} {} {}\n".format(station+1, user+1, distance_matrix[trajectory_matrix[user][current_time]][station]))
    moera_input_file_handler.write(";\n")

    moera_input_file_handler.write("param pre := \n")
    for station in range(num_stations):
        for user in range(num_users):
            if current_time == 0:
                moera_input_file_handler.write("{} {} 0\n".format(station+1, user+1))
            else:
                moera_input_file_handler.write("{} {} {}\n".format(station+1, user+1, previous_solution_matrix[station][user]))
    moera_input_file_handler.write(";\n")

    moera_input_file_handler.close()


def generate_greedy_input_file(greedy_input_file, current_time, num_stations, num_users, operation_price_matrix, \
                               bandwidth_price_matrix, reconfiguration_price_matrix, distance_matrix,\
                               trajectory_matrix, selection_matrix, workload_matrix, capacity_matrix, previous_solution_matrix, \
                               param_alpha, param_beta):

    greedy_input_file_handler = open(greedy_input_file, 'w')
    greedy_input_file_handler.write("param i := {} ;\n".format(num_stations))
    greedy_input_file_handler.write("param j := {} ;\n".format(num_users))

    greedy_input_file_handler.write("param alpha := {} ;\n".format(param_alpha))
    greedy_input_file_handler.write("param beta := {} ;\n".format(param_beta))

    greedy_input_file_handler.write("param s := \n")
    for user in range(num_users):
        for station in range(num_stations):
            greedy_input_file_handler.write("{} {} {}\n".format(user+1, station+1, selection_matrix[user][station]))
    greedy_input_file_handler.write(";\n")


    greedy_input_file_handler.write("param a :=\n")
    for station in range(num_stations):
        greedy_input_file_handler.write("{} {}\n".format(station+1, operation_price_matrix[station][current_time]))
    greedy_input_file_handler.write(";\n")

    greedy_input_file_handler.write("param c := \n")
    for station in range(num_stations):
        if current_time == 0:
            greedy_input_file_handler.write("{} {}\n".format(station+1, 0))
        else:
            greedy_input_file_handler.write("{} {}\n".format(station+1, reconfiguration_price_matrix[station]))
    greedy_input_file_handler.write(";\n")

    greedy_input_file_handler.write("param b := \n")
    for station in range(num_stations):
        if current_time == 0:
            greedy_input_file_handler.write("{} {}\n".format(station+1, 0))
        else:
            greedy_input_file_handler.write("{} {}\n".format(station+1, bandwidth_price_matrix[station]))
    greedy_input_file_handler.write(";\n")

    greedy_input_file_handler.write("param lbd := \n")
    for user in range(num_users):
        greedy_input_file_handler.write("{} {}\n".format(user+1, workload_matrix[user]))
    greedy_input_file_handler.write(";\n")

    greedy_input_file_handler.write("param cap := \n")
    for station in range(num_stations):
        greedy_input_file_handler.write("{} {}\n".format(station+1, capacity_matrix[station]))
    greedy_input_file_handler.write(";\n")

    greedy_input_file_handler.write("param d := \n")
    for user in range(num_users):
        for station in range(num_stations):
            greedy_input_file_handler.write("{} {} {}\n".format(station+1, user+1, distance_matrix[trajectory_matrix[user][current_time]][station]))
    greedy_input_file_handler.write(";\n")

    greedy_input_file_handler.write("param pre := \n")
    for station in range(num_stations):
        for user in range(num_users):
            if current_time == 1:
                greedy_input_file_handler.write("{} {} 0\n".format(station+1, user+1))
            else:
                greedy_input_file_handler.write("{} {} {}\n".format(station+1, user+1, previous_solution_matrix[station][user]))
    greedy_input_file_handler.write(";\n")

    greedy_input_file_handler.close()


def generate_future_input_file(future_input_file, current_time, num_stations, num_users, operation_price_matrix, \
                               bandwidth_price_matrix, reconfiguration_price_matrix, distance_matrix,\
                               trajectory_matrix, selection_matrix, workload_matrix, capacity_matrix, previous_solution_matrix, \
                               param_alpha, param_beta, num_timeslots, num_future_slots):

    cap_num_future_slots = min(num_timeslots - current_time, num_future_slots + 1)

    future_input_file_handler = open(future_input_file, 'w')
    future_input_file_handler.write("param t := {} ;\n".format(cap_num_future_slots))
    future_input_file_handler.write("param i := {} ;\n".format(num_stations))
    future_input_file_handler.write("param j := {} ;\n".format(num_users))

    future_input_file_handler.write("param alpha := {} ;\n".format(param_alpha))
    future_input_file_handler.write("param beta := {} ;\n".format(param_beta))

    # Selected stations
    future_input_file_handler.write("param s := \n")
    for user in range(num_users):
        for station in range(num_stations):
            future_input_file_handler.write(
                "{} {} {}\n".format(user + 1, station + 1, selection_matrix[user][station]))
    future_input_file_handler.write(";\n")

    # Time-varying operation cost
    future_input_file_handler.write("param a := \n")
    for station in range(num_stations):
        for time in range(current_time, current_time + cap_num_future_slots):
            future_input_file_handler.write("{} {} {}\n".format(station + 1, time - current_time + 1, operation_price_matrix[station][time]))
    future_input_file_handler.write(";\n")

    future_input_file_handler.write("param c := \n")
    for station in range(num_stations):

        # Exclude the reconfiguration at startup
        if current_time == 0:
            future_input_file_handler.write("{} {}\n".format(station + 1, 0))
        else:
            future_input_file_handler.write("{} {}\n".format(station + 1, reconfiguration_price_matrix[station]))
    future_input_file_handler.write(";\n")

    future_input_file_handler.write("param b := \n")
    for station in range(num_stations):

        # Exclude the migration cost at startup
        if current_time == 0:
            future_input_file_handler.write("{} {}\n".format(station + 1, 0))
        else:
            future_input_file_handler.write("{} {}\n".format(station + 1, bandwidth_price_matrix[station]))
    future_input_file_handler.write(";\n")


    future_input_file_handler.write("param d := \n")
    for user in range(num_users):
        for station in range(num_stations):
            future_input_file_handler.write("[{},{},*] ".format(station + 1, user + 1))
            for time in range(current_time, current_time + cap_num_future_slots):
                future_input_file_handler.write(
                    "{} {} ".format(time - current_time + 1, distance_matrix[trajectory_matrix[user][time]][station]))
            future_input_file_handler.write("\n")
    future_input_file_handler.write(";\n")

    future_input_file_handler.write("param lbd := \n")
    for user in range(num_users):
        future_input_file_handler.write("{} {}\n".format(user + 1, workload_matrix[user]))
    future_input_file_handler.write(";\n")

    future_input_file_handler.write("param cap := \n")
    for station in range(num_stations):
        future_input_file_handler.write("{} {}\n".format(station + 1, capacity_matrix[station]))
    future_input_file_handler.write(";\n")

    future_input_file_handler.write("param pre := \n")
    for station in range(num_stations):
        for user in range(num_users):
            if current_time == 0:
                future_input_file_handler.write("{} {} 0\n".format(station + 1, user + 1))
            else:
                future_input_file_handler.write(
                    "{} {} {}\n".format(station + 1, user + 1, previous_solution_matrix[station][user]))
    future_input_file_handler.write(";\n")

    future_input_file_handler.close()


def seperate_trajectory_hourly_darmstadt(date):

    trajectory_matrix_file = "../data/trajectory/darmstadt/40percent/darmstadt_student_{}_trajectory.dat".format(date)

    trajectory_matrix_file_handler = open(trajectory_matrix_file, 'r')
    lines = trajectory_matrix_file_handler.readlines()
    trajectory_matrix_file_handler.close()

    num_users = len(lines)
    random.seed(a=None)

    trajectory_matrix = []
    for line in lines:
        trajectory_matrix.append(map(int, line.split()))

    for hour in range(12):
        trajectory_matrix_hourly = [trajectory_matrix[user][hour * 60: (hour + 1) * 60] for user in range(num_users)]

        for user in range(num_users):
            for minute in range(60):
                if trajectory_matrix_hourly[user][minute] == -1:
                    trajectory_matrix_hourly[user][minute] = random.randint(0, 49)

        trajectory_matrix_hourly_file_handler = open("../data/trajectory/darmstadt/hourly/20150207_{}.dat".format(hour + 8), 'w')
        for user in range(num_users):
            for minute in range(60):
                trajectory_matrix_hourly_file_handler.write("{} ".format(trajectory_matrix_hourly[user][minute]))
            trajectory_matrix_hourly_file_handler.write('\n')
        trajectory_matrix_hourly_file_handler.close()
