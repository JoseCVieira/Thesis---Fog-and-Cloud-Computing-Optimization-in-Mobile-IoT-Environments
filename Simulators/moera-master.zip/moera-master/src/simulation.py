import sys
import os
import argparse
import util
import random

from model import *


def run_optimal(input_opt):

    #print "Creating instance..."
    abs_model = create_abs_opt()
    instance = abs_model.create_instance(input_opt)
    opt = SolverFactory("ipopt")

    #print "Solving..."
    results = opt.solve(instance, options={'tol': 0.01})
    instance.solutions.store_to(results)
    return instance


def run_moera(input_approx):

    #print "Creating instance..."
    abs_model = create_abs_moera()
    instance = abs_model.create_instance(input_approx)
    opt = SolverFactory("ipopt")

    #print "Solving..."
    results = opt.solve(instance)
    instance.solutions.store_to(results)
    return instance


def run_greedy(input_greedy):

    #print "Creating instance..."
    abs_model = create_abs_greedy()
    instance = abs_model.create_instance(input_greedy)
    opt = SolverFactory("ipopt")

    #print "Solving..."
    results = opt.solve(instance)
    instance.solutions.store_to(results)
    return instance


def run_greedy_performance(input_perf):

    #print "Creating instance..."
    abs_model = create_abs_greedy_perf()
    instance = abs_model.create_instance(input_perf)
    opt = SolverFactory("ipopt")

    #print "Solving..."
    results = opt.solve(instance)
    instance.solutions.store_to(results)
    return instance


def run_greedy_operation(input_operation):

    #print "Creating instance..."
    abs_model = create_abs_greedy_operation()
    instance = abs_model.create_instance(input_operation)
    opt = SolverFactory("ipopt")

    #print "Solving..."
    results = opt.solve(instance)
    instance.solutions.store_to(results)
    return instance


def run_greedy_static(input_static):

    #print "Creating instance..."
    abs_model = create_abs_greedy_static()
    instance = abs_model.create_instance(input_static)
    opt = SolverFactory("ipopt")

    #print "Solving..."
    results = opt.solve(instance)
    instance.solutions.store_to(results)
    return instance


def run_future(input_future):
    abs_model = create_abs_future()
    instance = abs_model.create_instance(input_future)
    opt = SolverFactory("ipopt")

    results = opt.solve(instance)
    instance.solutions.store_to(results)
    return instance


def main(distance_matrix_file, trajectory_matrix_file, workload_type = 0, selectiveness = 0, solution_type = "",
         param_alpha = 1.0, param_beta = 1.0, param_eps1 = 0.1, param_eps2 = 0.1, num_future_slots = 0):


    random.seed(a=None)
    temp_file_dir = "temp{}".format(random.randint(1000,50000))

    os.system("mkdir {}".format(temp_file_dir))


    operation_price_matrix = []
    bandwidth_price_matrix = []
    reconfiguration_price_matrix = []

    distance_matrix = util.read_distance_matrix(distance_matrix_file)
    trajectory_matrix = util.read_trajectory_matrix(trajectory_matrix_file)
    
    num_stations = len(distance_matrix)
    num_users = len(trajectory_matrix)
    num_timeslots = len(trajectory_matrix[0])


    workload_matrix = []
    capacity_matrix = []

    if workload_type or selectiveness:

        if workload_type:
            util.generate_operation_price_matrix_file(num_stations, num_timeslots, temp_file_dir)
            util.generate_bandwidth_price_matrix_file(num_stations, temp_file_dir)
            util.generate_reconfiguration_price_file(num_stations, temp_file_dir)

            util.generate_workload_matrix_file(num_users, workload_type, temp_file_dir)
            workload_matrix = util.read_workload_matrix("./{}/workload.dat".format(temp_file_dir))
            util.generate_capacity_matrix_file(num_stations, workload_matrix, trajectory_matrix, temp_file_dir)

        if selectiveness:
            util.generate_selection_matrix_file(num_users, num_stations, selectiveness, temp_file_dir)



    operation_price_matrix = util.read_operation_price_matrix("./{}/operation_price.dat".format(temp_file_dir))
    bandwidth_price_matrix = util.read_bandwidth_price_matrix("./{}/bandwidth_price.dat".format(temp_file_dir))
    reconfiguration_price_matrix = util.read_reconfiguration_price_matrix("./{}/reconfiguration_price.dat".format(temp_file_dir))

    selection_matrix = util.read_selection_matrix("./{}/selection.dat".format(temp_file_dir))
    workload_matrix = util.read_workload_matrix("./{}/workload.dat".format(temp_file_dir))
    capacity_matrix = util.read_capacity_matrix("./{}/capacity.dat".format(temp_file_dir))



    # Generate optimal solution
    if solution_type[0] == '1':
        
        optimal_input_file = "./{}/optimal_input.dat".format(temp_file_dir)
        util.generate_optimal_input_file(optimal_input_file, num_stations, num_users, num_timeslots,
                                         operation_price_matrix, bandwidth_price_matrix, reconfiguration_price_matrix,
                                         distance_matrix, trajectory_matrix, selection_matrix, workload_matrix,
                                         capacity_matrix, param_alpha, param_beta)
        optimal_instance = run_optimal(optimal_input_file)

        #for t in range(nt):
            #print "Resource allocated: {}".format(
            #    sum(sum(instance.x[i + 1, j + 1, t + 1].value for j in range(nj)) for i in range(ni)))
            #print "Resource needed: {}".format(sum(mat_lbd[j] for j in range(nj)))

        print "OPT: {}".format(optimal_instance.OBJ())



    # Generate MOERA solution
    if solution_type[1] == '1':

        moera_static_cost = 0
        moera_dynamic_cost = 0
        
        previous_solution_matrix = [[0 for user in range(num_users)] for station in range(num_stations)]

        for time in range(num_timeslots):

            #print "Starting iteration {}...".format(t + 1)

            moera_input_file = "./{}/moera_input_time_{}.dat".format(temp_file_dir, time+1)
            util.generate_moera_input_file(moera_input_file, time, num_stations, num_users, operation_price_matrix,
                                           bandwidth_price_matrix, reconfiguration_price_matrix, distance_matrix,
                                           trajectory_matrix, selection_matrix, workload_matrix, capacity_matrix,
                                           previous_solution_matrix, param_alpha, param_beta, param_eps1, param_eps2)
            moera_instance = run_moera(moera_input_file)

            moera_static_cost += param_alpha * sum(sum(
                                operation_price_matrix[station][time] * moera_instance.x[station+1, user+1].value
                                for user in range(num_users)) for station in range(num_stations))
            moera_static_cost += param_alpha * sum(sum(
                                distance_matrix[station][trajectory_matrix[user][time]] *
                                moera_instance.x[station+1, user+1].value
                                for user in range(num_users)) for station in range(num_stations))


            if time != 0:
                for station in range(num_stations):
                    current_load = sum(moera_instance.x[station+1, user+1].value for user in range(num_users))
                    previous_load = sum(previous_solution_matrix[station][user] for user in range(num_users))
                    moera_dynamic_cost += param_beta * reconfiguration_price_matrix[station] * \
                                          (abs(current_load - previous_load) + current_load - previous_load) / 2
                    moera_dynamic_cost += param_beta * sum(sum(
                        bandwidth_price_matrix[station] *
                        (abs(moera_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])
                         + (moera_instance.x[station+1, user+1].value - previous_solution_matrix[station][user]))/2
                        for user in range(num_users)) for station in range(num_stations))

            # print "Resource allocated: {}".format(
            #     sum(sum(moera_instance.x[station+1, user+1].value for user in range(num_users)) for station in range(num_stations)))
            # print "Resource needed: {}".format(sum(workload_matrix[user] for user in range(num_users)))

            for station in range(num_stations):
                for user in range(num_users):
                    previous_solution_matrix[station][user] = moera_instance.x[station+1, user+1].value

        print "MOERA: {}".format(moera_static_cost + moera_dynamic_cost), "({},{})".format(moera_static_cost, moera_dynamic_cost)


    
    # Generate the greedy solution
    if solution_type[2] == '1':

        greedy_cost = 0
        greedy_static_cost = 0
        greedy_dynamic_cost = 0

        previous_solution_matrix = [[0 for user in range(num_users)] for station in range(num_stations)]

        for time in range(num_timeslots):

            #print "Starting iteration {}...".format(t + 1)

            greedy_input_file = "./{}/greedy_input_time_{}.dat".format(temp_file_dir, time + 1)
            util.generate_greedy_input_file(greedy_input_file, time, num_stations, num_users,
                                            operation_price_matrix, bandwidth_price_matrix,
                                            reconfiguration_price_matrix, distance_matrix,
                                            trajectory_matrix, selection_matrix, workload_matrix, capacity_matrix,
                                            previous_solution_matrix, param_alpha, param_beta)
            greedy_instance = run_greedy(greedy_input_file)

            greedy_static_cost += param_alpha * sum(sum(
                        operation_price_matrix[station][time] * greedy_instance.x[station+1, user+1].value
                        for user in range(num_users)) for station in range(num_stations))
            greedy_static_cost += param_alpha * sum(sum(
                        distance_matrix[station][trajectory_matrix[user][time]] * greedy_instance.x[station+1, user+1].value
                        for user in range(num_users)) for station in range(num_stations))

            if time != 0:
                for station in range(num_stations):
                    current_load = sum(greedy_instance.x[station+1, user+1].value for user in range(num_users))
                    previous_load = sum(previous_solution_matrix[station][user] for user in range(num_users))
                    greedy_dynamic_cost += param_beta * reconfiguration_price_matrix[station] * \
                                           (abs(current_load - previous_load) + current_load - previous_load) / 2

                    greedy_dynamic_cost += param_beta * sum(sum(bandwidth_price_matrix[station] *
                        (abs(greedy_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])
                         + (greedy_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])) / 2
                        for user in range(num_users)) for station in range(num_stations))

            # print "Resource allocated: {}".format(
            #     sum(sum(greedy_instance.x[station + 1, user + 1].value for user in range(num_users)) for station in
            #         range(num_stations)))
            # print "Resource needed: {}".format(sum(workload_matrix[user] for user in range(num_users)))


            for station in range(num_stations):
                for user in range(num_users):
                    previous_solution_matrix[station][user] = greedy_instance.x[station+1, user+1].value

        print "GREEDY: {}".format(greedy_static_cost + greedy_dynamic_cost), "({},{})".format(greedy_static_cost, greedy_dynamic_cost)


    # Generate the performance-only solution
    if solution_type[3] == '1':

        performance_cost = 0
        previous_solution_matrix = [[0 for user in range(num_users)] for station in range(num_stations)]

        for time in range(num_timeslots):

            #print "Starting iteration {}...".format(t + 1)

            performance_input_file = "./{}/performance_input_time_{}.dat".format(temp_file_dir, time + 1)
            util.generate_greedy_input_file(performance_input_file, time, num_stations, num_users,
                                            operation_price_matrix, bandwidth_price_matrix,
                                            reconfiguration_price_matrix, distance_matrix,
                                            trajectory_matrix, selection_matrix, workload_matrix, capacity_matrix,
                                            previous_solution_matrix, param_alpha, param_beta)
            performance_instance = run_greedy_performance(performance_input_file)

            performance_cost += param_alpha * sum(sum(
                operation_price_matrix[station][time] * performance_instance.x[station+1, user+1].value
                for user in range(num_users)) for station in range(num_stations))
            performance_cost += param_alpha * sum(sum(
                distance_matrix[station][trajectory_matrix[user][time]] * performance_instance.x[station+1, user+1].value
                for user in range(num_users)) for station in range(num_stations))

            if time != 0:
                for station in range(num_stations):
                    current_load = sum(performance_instance.x[station+1, user+1].value for user in range(num_users))
                    previous_load = sum(previous_solution_matrix[station][user] for user in range(num_users))
                    performance_cost += param_beta * reconfiguration_price_matrix[station] * \
                                        (abs(current_load - previous_load) + current_load - previous_load) / 2

                    performance_cost += param_beta * sum(sum(bandwidth_price_matrix[station] *
                        (abs(performance_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])
                         + (performance_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])) / 2
                        for user in range(num_users)) for station in range(num_stations))

            #print "Resource allocated: {}".format(
            #    sum(sum(instance.x[i + 1, j + 1].value for j in range(nj)) for i in range(ni)))
            #print "Resource needed: {}".format(sum(mat_lbd[j] for j in range(nj)))

            for station in range(num_stations):
                for user in range(num_users):
                    previous_solution_matrix[station][user] = performance_instance.x[station+1, user+1].value

        print "PERFORMANCE: {}".format(performance_cost)


    # Generate the operation-only solution
    if solution_type[4] == '1':

        operation_cost = 0
        previous_solution_matrix = [[0 for user in range(num_users)] for station in range(num_stations)]

        for time in range(num_timeslots):

            # print "Starting iteration {}...".format(t + 1)

            operation_input_file = "./{}/operation_input_time_{}.dat".format(temp_file_dir, time+1)
            util.generate_greedy_input_file(operation_input_file, time, num_stations, num_users,
                                            operation_price_matrix, bandwidth_price_matrix,
                                            reconfiguration_price_matrix, distance_matrix,
                                            trajectory_matrix, selection_matrix, workload_matrix, capacity_matrix,
                                            previous_solution_matrix, param_alpha, param_beta)
            operation_instance = run_greedy_operation(operation_input_file)

            operation_cost += param_alpha * sum(sum(
                operation_price_matrix[station][time] * operation_instance.x[station+1, user+1].value
                for user in range(num_users)) for station in range(num_stations))
            operation_cost += param_alpha * sum(sum(
                distance_matrix[station][trajectory_matrix[user][time]] * operation_instance.x[station+1, user+1].value
                for user in range(num_users)) for station in range(num_stations))

            if time != 0:
                for station in range(num_stations):
                    current_load = sum(operation_instance.x[station+1, user+1].value for user in range(num_users))
                    previous_load = sum(previous_solution_matrix[station][user] for user in range(num_users))
                    operation_cost += param_beta * reconfiguration_price_matrix[station] * (
                        abs(current_load - previous_load) + current_load - previous_load) / 2

                    operation_cost += param_beta * sum(sum(
                        bandwidth_price_matrix[station] * (
                        abs(operation_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])
                        + (
                        operation_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])) / 2
                        for user in range(num_users)) for station in range(num_stations))

            # print "Resource allocated: {}".format(
            #    sum(sum(instance.x[i + 1, j + 1].value for j in range(nj)) for i in range(ni)))
            # print "Resource needed: {}".format(sum(mat_lbd[j] for j in range(nj)))

            for station in range(num_stations):
                for user in range(num_users):
                    previous_solution_matrix[station][user] = operation_instance.x[station+1, user+1].value

        print "OPERATION: {}".format(operation_cost)


    # Generate the static-only solution
    if solution_type[5] == '1':

        static_cost = 0
        previous_solution_matrix = [[0 for user in range(num_users)] for station in range(num_stations)]

        for time in range(num_timeslots):

            #print "Starting iteration {}...".format(t + 1)

            static_input_file = "./{}/static_input_time_{}.dat".format(temp_file_dir, time+1)
            util.generate_greedy_input_file(static_input_file, time, num_stations, num_users,
                                            operation_price_matrix, bandwidth_price_matrix,
                                            reconfiguration_price_matrix, distance_matrix,
                                            trajectory_matrix, selection_matrix, workload_matrix, capacity_matrix,
                                            previous_solution_matrix, param_alpha, param_beta)
            static_instance = run_greedy_static(static_input_file)

            static_cost += param_alpha * sum(sum(
                operation_price_matrix[station][time] * static_instance.x[station+1, user+1].value
                for user in range(num_users)) for station in range(num_stations))
            static_cost += param_alpha * sum(sum(
                distance_matrix[station][trajectory_matrix[user][time]] * static_instance.x[station+1, user+1].value
                for user in range(num_users)) for station in range(num_stations))

            if time != 0:
                for station in range(num_stations):
                    current_load = sum(static_instance.x[station+1, user+1].value for user in range(num_users))
                    previous_load = sum(previous_solution_matrix[station][user] for user in range(num_users))
                    static_cost += param_beta * reconfiguration_price_matrix[station] * \
                                   (abs(current_load - previous_load) + current_load - previous_load) / 2
                    static_cost += param_beta * sum(sum(bandwidth_price_matrix[station] *
                        (abs(static_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])
                        + (static_instance.x[station+1, user+1].value - previous_solution_matrix[station][user])) / 2
                        for user in range(num_users)) for station in range(num_stations))

            #print "Resource allocated: {}".format(
            #    sum(sum(instance.x[i + 1, j + 1].value for j in range(nj)) for i in range(ni)))
            #print "Resource needed: {}".format(sum(mat_lbd[j] for j in range(nj)))

            for station in range(num_stations):
                for user in range(num_users):
                    previous_solution_matrix[station][user] = static_instance.x[station+1, user+1].value

        print "STATIC: {}".format(static_cost)




    # Generate the solution with partial future knowledge
    if solution_type[6] == '1':

        future_cost = 0

        previous_solution_matrix = [[0 for user in range(num_users)] for station in range(num_stations)]

        for time in range(num_timeslots):

            future_input_file = "./{}/future_input_time_{}.dat".format(temp_file_dir, time+1)
            util.generate_future_input_file(future_input_file, time, num_stations, num_users,
                                            operation_price_matrix, bandwidth_price_matrix, reconfiguration_price_matrix,
                                            distance_matrix, trajectory_matrix, selection_matrix,
                                            workload_matrix, capacity_matrix, previous_solution_matrix,
                                            param_alpha, param_beta, num_timeslots, num_future_slots)

            future_instance = run_future(future_input_file)

            future_cost += param_alpha * sum(sum(
                operation_price_matrix[station][time] * future_instance.x[station+1, user+1, 1].value
                for user in range(num_users)) for station in range(num_stations))
            future_cost += param_alpha * sum(sum(
                distance_matrix[station][trajectory_matrix[user][time]] * future_instance.x[station+1, user+1, 1].value
                for user in range(num_users)) for station in range(num_stations))

            # No dynamic cost for the first time slot
            if time != 0:
                for station in range(num_stations):
                    current_load =sum(future_instance.x[station+1, user+1, 1].value for user in range(num_users))
                    previous_load = sum(previous_solution_matrix[station][user] for user in range(num_users))
                    future_cost += param_beta * reconfiguration_price_matrix[station] * \
                                    (abs(current_load - previous_load) + current_load - previous_load)/2
                    future_cost += param_beta * sum(sum(bandwidth_price_matrix[station] *
                                                         (abs(future_instance.x[station+1, user+1, 1].value - previous_solution_matrix[station][user])
                                                          + future_instance.x[station+1, user+1, 1].value - previous_solution_matrix[station][user])/2
                                                        for user in range(num_users)) for station in range(num_stations))

            for station in range(num_stations):
                for user in range(num_users):
                    previous_solution_matrix[station][user] = future_instance.x[station+1, user+1, 1].value

        print "FUTURE: {}".format(future_cost)





if __name__ == '__main__':

    path = os.path.abspath(os.path.dirname(sys.argv[0]))

    parser = argparse.ArgumentParser(description="MOERA EXPERIMENTS")
    parser.add_argument('-d', "--distance", help='distrance matrix file',
                        default="../data/distance/rome_metro_dist.dat")
    parser.add_argument('-t', "--trajectory", help='trajectory matrix file',
                        default="../data/trajectory/rome/rome_taxi_2014021215_trajectory.dat")
    parser.add_argument('-g', "--generate", help='generate new data: 0:no 1:powerlaw 2:normal 3:uniform', default=0)
    parser.add_argument('-s', "--selectiveness", help='choose proportion', default=0)
    parser.add_argument('-r', "--solution", help='choose solution', default="")
    parser.add_argument('-a', "--alpha", type=float, help='alpha', default=1.0)
    parser.add_argument('-b', "--beta", type=float, help='beta', default=1.0)
    parser.add_argument('-e', "--epsilon", type=float, help='epsilon', default=0.1)
    parser.add_argument('-f', "--future", type=int, help="number of future timeslots", default=0)

    args = parser.parse_args()


    main(args.distance, args.trajectory, args.generate, float(args.selectiveness), args.solution,
         float(args.alpha), float(args.beta), float(args.epsilon), float(args.epsilon), int(args.future))
